All credits to ChatGPT for creating these tests :)

1.  copy test folder to project foler, make sure your project files are outside of test folder
2.  run command: "dos2unix run.sh && chmod +x run.sh"
3a. run command: "./run.sh"    to run witout diff output.
3b. run command: "./run.sh -d" to run with diff output.