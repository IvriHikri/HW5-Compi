Copy files to server, add your code (including the makefile)
run command: "dos2unix ./run.sh && chmod 777 ./run.sh"
run command: "./run.sh"
